#pragma once

#ifndef WEBGL_APICALL

#ifdef __cplusplus
#define WEBGL_APICALL extern "C"
#else
#define WEBGL_APICALL
#endif

#endif
